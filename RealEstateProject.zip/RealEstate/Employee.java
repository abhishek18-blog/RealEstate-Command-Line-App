interface Employee{
    void setEmployeeId(String id);
    String getEmployeeId();

    void setSalary(double  salary);
    double getSalary();

}