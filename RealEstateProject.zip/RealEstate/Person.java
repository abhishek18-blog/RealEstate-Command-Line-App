interface Person{
    void setName(String name);
    String getName();
}